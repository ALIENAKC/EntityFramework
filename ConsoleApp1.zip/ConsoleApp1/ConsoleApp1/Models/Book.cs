﻿using ConsoleApp1.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1.Models
{
    public class Book : Entity
    {
        [JsonProperty("title")]
        public string Title { get; set; }
#nullable enable
        public Guid? ClientId { get; set; }
        public Client? Client { get; set; }
#nullable disable
        public List<Author> Authors { get; set; }   
        /*public List<AuthorBook> AuthorBooks { get; set; }*/
    }
}
