﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1.Models
{
    public class Client : Entity
    {
        [JsonProperty("name")]
        public string Name { get; set; }
        public string FamylyName { get; set; }
        public bool IsOwe { get; set; }
        public List<Book> BorrowedBooks { get; set; }

    }
}
