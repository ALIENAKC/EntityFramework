﻿using ConsoleApp1.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ConsoleApp1.Models
{
    public class Author : Entity
    {
        [JsonProperty("name")]
        public string Name { get; set; }
        public string FamilyName { get; set; }
        public List<Book> Books { get; set; }
        public List<AuthorBook> authorBooks { get; set; }
    }
}
