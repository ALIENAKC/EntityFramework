﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ConsoleApp1.Models
{
    public abstract class Entity
    {
        [Key]
        public Guid Id { get; private set; }
        protected Entity()
        {
            Id = Guid.NewGuid();
        }
    }
}
