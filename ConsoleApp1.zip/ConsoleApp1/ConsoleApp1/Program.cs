﻿using ConsoleApp1.DataAccess;
using ConsoleApp1.DataAccess.Models;
using System;
using System.Linq;

namespace ConsoleApp1.Models
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new ApplicationContext())
            {
                context.Authors.AddRange(DataSeed.GetAuthors());
                context.clients.AddRange(DataSeed.GetClients());
                context.Books.AddRange(DataSeed.GetBooks());
                context.SaveChanges();
            }
        }
    }
}
