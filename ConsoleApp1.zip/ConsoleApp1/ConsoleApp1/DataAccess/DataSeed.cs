﻿using ConsoleApp1.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace ConsoleApp1.DataAccess
{
    class DataSeed
    {
        public static List<Book> GetBooks()
        {
            using(var file = new StreamReader("/Books.json"))
            {
                var bookString = file.ReadToEnd();
                var books = new List<Book>();
                return JsonConvert.DeserializeObject<List<Book>>(bookString);
            }
        }

        public static List<Client> GetClients()
        {
            using (var file = new StreamReader("/Clients.json"))
            {
                var clientString = file.ReadToEnd();
                var clients = new List<Client>();
                return JsonConvert.DeserializeObject<List<Client>>(clientString);
            }
        }

        public static List<Author> GetAuthors()
        {
            using (var file = new StreamReader("/Authors.json"))
            {
                var authorString = file.ReadToEnd();
                var authors = new List<Author>();
                return JsonConvert.DeserializeObject<List<Author>>(authorString);
            }
        }
    }
}
